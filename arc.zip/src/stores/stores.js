import { useAppStore } from './app'

export const appStore = useAppStore()
